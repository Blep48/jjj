# DUEL — 1v1 arcade minigame prototype

A mobile-first, dark neon arcade app where you duel a simulated opponent in a 5-round reaction test, betting play-money "Duel Coins".

## Economy rules
- Starter balance: 10,000 Duel Coins (demo currency only, no real money).
- Entry fee: 100 per match. Win: +190 net (+90 after fee). Loss: -100.
- Rating moves +/- 15 points per match, Elo-style.

## Screens
1. **Home** — DUEL logo, coin balance, rating, quick stats (played / wins / win rate / best reaction), big PLAY button, recent match list, links to Leaderboard and Profile.
2. **Game selection** — REACTION playable; RHYTHM, DIRECTION, MEMORY, PRECISION shown as locked "coming soon".
3. **Matchmaking** — "Searching for opponent…" with pulsing radar animation, pairs in 2–4 seconds with a bot that has a username, avatar, rating and its own realistic reaction profile. Shows a short "opponent found" versus card before starting.
4. **Reaction game** — GET READY, 3‑2‑1 countdown, then 5 rounds. Each round waits a random 1.5–4.5s, then the target turns vibrant green; tap time measured in ms. Tapping early = false start, round penalised. Header shows round 1/5, last time, running average, best time.
5. **Result** — side-by-side average comparison, WIN / DEFEAT banner, coin delta, rating delta, REMATCH (straight back to matchmaking) and BACK TO HOME.
6. **Profile** — username edit, avatar picker, rating, games played, wins, losses, win rate, best reaction, balance.
7. **Leaderboard** — 20+ seeded players sorted by rating with the current player highlighted in place.

## Look and feel
Portrait-first dark arcade theme: near-black background, neon green primary with magenta/cyan accents, condensed display type for numbers, large touch targets, fast fade/scale transitions. Optional sound via Web Audio synthesis (countdown beeps, win chime, false-start buzz) with a mute toggle.

## Technical notes
- Routes: `/` (home), `/games`, `/match` (matchmaking), `/play/reaction`, `/result`, `/profile`, `/leaderboard`, each with its own page metadata.
- Strict module separation so real multiplayer can drop in later:
  - `lib/duel/types.ts` — shared domain types.
  - `lib/duel/storage.ts` — persistence adapter (localStorage now, swappable for a database later).
  - `lib/duel/player.ts` — profile, stats, rating maths.
  - `lib/duel/economy.ts` — fee, payout, balance guards.
  - `lib/duel/matchmaking.ts` — service interface + local bot implementation.
  - `lib/duel/engine/reaction.ts` — pure round/score logic, no React.
  - `lib/duel/audio.ts` — Web Audio cues.
  - React state via a `DuelProvider` context; screens stay presentation-only.
- Match state passed between matchmaking → game → result through the provider, so a refresh returns you home rather than into a broken match.
- No backend for this prototype; data lives on the device. Adding accounts and server-checked results later means replacing the storage and matchmaking adapters only.

## Verification
Drive the full loop in a headless browser: Home → Play → Reaction → Matchmaking → 5 rounds → Result → Rematch, checking balance, rating and history update correctly and that a false start is handled.
